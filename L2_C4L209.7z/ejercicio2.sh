#!/bin/bash

if [ $# -eq 0 ]; then 
    echo "Error: Faltan argumentos"
    echo "Ejemplo: ./ejercicio2.sh firefox"
    exit 1
fi

comando=$1
archivo_log="archivo2.log"
imagen_salida="consumo_recursos.png"

# Codigo principal
$comando &
pid_proceso=$!

echo "Tiempo CPU(%) Memoria(%)" > "$archivo_log"

while ps -p "$pid_proceso" > /dev/null; do
    stats=$(ps -p "$pid_proceso" -o %cpu=,%mem= --no-headers)
    
    if [[ "$stats" =~ [0-9] ]]; then
        echo "$(date '+%H:%M:%S') $stats" >> "$archivo_log"
    fi
    sleep 1
done

if command -v gnuplot >/dev/null 2>&1; then
    gnuplot <<- GNUEOF
        set terminal pngcairo size 1000,600 enhanced font "Verdana,10"
        set output '$imagen_salida'
        set title "Consumo de Recursos - $comando"
        set xlabel "Tiempo"
        set ylabel "Porcentaje"
        set grid
        set key left top
        set style line 1 lt 1 lc rgb "#3498db" lw 2
        set style line 2 lt 1 lc rgb "#e74c3c" lw 2
        
        stats '$archivo_log' using 2 nooutput
        
        if (STATS_records > 0) {
            plot '$archivo_log' using 2 with lines ls 1 title "CPU", \
                 '' using 3 with lines ls 2 title "Memoria"
        } else {
            print "Error: No hay datos válidos para graficar"
        }
GNUEOF

fi