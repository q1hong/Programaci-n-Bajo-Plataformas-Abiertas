#!/bin/bash

if [ "$(id -u)" != "0" ]; then
    echo "Error: El script se debe ejecutar este script como root" 
    exit 1
fi

if [ $# -ne 3 ]; then
    echo "Error: Faltan parametros: <usuario> <grupo> <rutas_archivo>"
    exit 1
fi

usuario=$1
grupo=$2
ruta=$3

if [ ! -e $ruta ]; then
    echo "Error: La ruta del archivo no existe" 
    exit 1
fi

if grep -q "^$grupo:" /etc/group; then
    echo "El grupo "$grupo" existe"
else
    addgroup "$grupo"

fi

if id "$usuario" &>/dev/null; then 
    echo "El usuario $usuario existe"
    usermod -aG "$grupo" "$usuario"
else
    adduser "$usuario"
    usermod -aG "$grupo" "$usuario"
    
fi

chown "$usuario:$grupo" "$ruta"
chmod 740 $ruta

