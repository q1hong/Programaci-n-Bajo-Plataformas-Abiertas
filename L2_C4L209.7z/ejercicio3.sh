#!/bin/bash

directorio="$1"
archivo_log="cambios.log"

monitorear_cambios() {
    echo "Iniciando monitoreo de: $directorio"
    echo "Registrando cambios en: $archivo_log"
    echo "Presiona Ctrl+C para detener..."

    inotifywait -m -r -q --format '%T %e %w%f' --timefmt '%Y-%m-%d %H:%M:%S' \
    -e create,modify,delete "$directorio" | while read LINE
    do
        echo "$LINE" >> "$archivo_log"
        echo "[$(date '+%H:%M:%S')] $LINE" 
    done
}

clear
echo "=== MONITOR DE CAMBIOS ==="
monitorear_cambios